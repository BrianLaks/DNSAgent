$ErrorActionPreference = "Stop"
$ServiceName = "DNSAgent"
$DisplayName = "DNS Agent - Network Ad Blocker"

# --- FIX: Convert location to a STRING to avoid the "type PathInfo" error ---
$CurrentDir = (Get-Location).Path
$BinaryPath = Join-Path $CurrentDir "DNSAgent.Service.exe"
$TrayPath = Join-Path $CurrentDir "DNSAgent.Tray.exe"

Write-Host "--- DNS Agent Master Setup ---" -ForegroundColor Cyan

# 0. Cleanup: Kill processes listening on critical ports (53, 5123)
Write-Host "Checking for hung processes on critical ports..." -ForegroundColor Yellow
$PortsToClean = @(53, 5123)
foreach ($port in $PortsToClean) {
    $processes = Get-NetTCPConnection -LocalPort $port -ErrorAction SilentlyContinue | Select-Object -ExpandProperty OwningProcess
    $processes += Get-NetUDPEndpoint -LocalPort $port -ErrorAction SilentlyContinue | Select-Object -ExpandProperty OwningProcess
    
    foreach ($owningPid in ($processes | Select-Object -Unique)) {
        try {
            $p = Get-Process -Id $owningPid -ErrorAction SilentlyContinue
            if ($p) {
                Write-Host "Terminating process $($p.Name) (PID: $owningPid) listening on port $port..." -ForegroundColor Gray
                Stop-Process -Id $owningPid -Force -ErrorAction SilentlyContinue
            }
        }
        catch { }
    }
}

# Also kill by name just in case they aren't listening yet
Write-Host "Exterminating zombie processes..." -ForegroundColor Yellow
try {
    & taskkill.exe /F /IM "DNSAgent.Service.exe" /T 2>$null
    & taskkill.exe /F /IM "DNSAgent.Tray.exe" /T 2>$null
}
catch { }

Stop-Process -Name "DNSAgent.Service" -Force -ErrorAction SilentlyContinue
Stop-Process -Name "DNSAgent.Tray" -Force -ErrorAction SilentlyContinue
Start-Sleep -Seconds 1

# 1. Firewall Fix: Allow the Application itself (not just ports)
Write-Host "Configuring Application Firewall rules..." -ForegroundColor Yellow
Remove-NetFirewallRule -DisplayName "DNS Agent*" -ErrorAction SilentlyContinue
New-NetFirewallRule -DisplayName "DNS Agent - Service" -Direction Inbound -Program "$BinaryPath" -Action Allow -Profile Any
New-NetFirewallRule -DisplayName "DNS Agent - Tray" -Direction Inbound -Program "$TrayPath" -Action Allow -Profile Any

# 2. Service Cleanup & Data Rescue
Write-Host "Checking for existing installation..." -ForegroundColor Yellow
$OldService = Get-WmiObject Win32_Service -Filter "Name='$ServiceName'" -ErrorAction SilentlyContinue

if ($OldService) {
    try {
        # Extract binary path from ImagePath (handle quotes)
        $OldBinPath = $OldService.PathName -replace '"', ''
        $OldDir = Split-Path -Parent $OldBinPath
        $OldDb = Join-Path $OldDir "dnsagent.db"
        $NewDb = Join-Path $CurrentDir "dnsagent.db"

        if (Test-Path $OldDb) {
            # Check if we are already in the same directory (no rescue needed)
            if ($OldDir -eq $CurrentDir) {
                Write-Host "Service is already in this directory. Skipping database rescue." -ForegroundColor Gray
            }
            else {
                # Check if the "new" DB is just a placeholder (small size) or we just want to rescue the old one anyway
                if (Test-Path $NewDb) {
                    Write-Host "A database file already exists in the destination." -ForegroundColor Yellow
                    Write-Host "Backing up destination database to .bak..." -ForegroundColor Gray
                    Rename-Item $NewDb -NewName "dnsagent.db.bak.$(Get-Date -Format 'yyyyMMddHHmmss')" -Force
                }
                
                Write-Host "Found existing database at: $OldDb" -ForegroundColor Green
                Write-Host "Importing database to new installation..." -ForegroundColor Green
                Copy-Item $OldDb -Destination $NewDb -Force
            }
        }
    }
    catch {
        Write-Host "Warning: Could not import old database automatically. You may need to copy dnsagent.db manually." -ForegroundColor Red
    }
}

Write-Host "Stopping and removing old service..." -ForegroundColor Gray
Stop-Service $ServiceName -Force -ErrorAction SilentlyContinue
& sc.exe stop $ServiceName 2>$null
Start-Sleep -Seconds 1
& sc.exe delete $ServiceName 2>$null
Start-Sleep -Seconds 2

# Force remove any hung files in destination if possible
try {
    Get-Process -Name "DNSAgent.Service" -ErrorAction SilentlyContinue | Stop-Process -Force
    Get-Process -Name "DNSAgent.Tray" -ErrorAction SilentlyContinue | Stop-Process -Force
}
catch {}
Start-Sleep -Seconds 1

# 3. Install Service & FIX WEBSITE STYLING
Write-Host "Installing Service..." -ForegroundColor Yellow
$BinWithQuotes = "`"$BinaryPath`""
# 103: New-Service -Name $ServiceName -BinaryPathName $BinWithQuotes -DisplayName $DisplayName -Description "DNS Ad-Blocker" -StartupType Automatic

# 4. Sentinel Asset Verification: Ensure Extension is available for Dashboard
Write-Host "Verifying Sentinel assets..." -ForegroundColor Yellow
$AssetsPath = Join-Path $CurrentDir "wwwroot\assets"
if (!(Test-Path $AssetsPath)) {
    Write-Host "Note: Sentinel asset directory not found. Extension downloads may be unavailable from dashboard." -ForegroundColor Yellow
}
else {
    $ExtZips = Get-ChildItem $AssetsPath -Filter "DNSAgent_Extension_v*.zip"
    if ($ExtZips.Count -gt 0) {
        Write-Host "Sentinel assets verified: $($ExtZips[0].Name)" -ForegroundColor Green
    }
}

# This Registry fix tells Windows the "Working Directory" so it finds the CSS/Images
$RegPath = "HKLM:\SYSTEM\CurrentControlSet\Services\$ServiceName"
Set-ItemProperty -Path $RegPath -Name "ImagePath" -Value $BinWithQuotes

# 4. Start Service
Write-Host "Starting Service..." -ForegroundColor Cyan
Start-Service $ServiceName

# 5. FIX TRAY AUTO-START: Properly handling strings for the shortcut
if (Test-Path $TrayPath) {
    Write-Host "Configuring Tray Icon for Login auto-start..." -ForegroundColor Cyan
    $startupFolder = [Environment]::GetFolderPath("Startup")
    $shortcutPath = Join-Path $startupFolder "DNSAgentTray.lnk"
    
    $shell = New-Object -ComObject WScript.Shell
    $shortcut = $shell.CreateShortcut($shortcutPath)
    $shortcut.TargetPath = $TrayPath
    # Using the fixed string version of the path here:
    $shortcut.WorkingDirectory = $CurrentDir 
    $shortcut.Save()
    
    # Start it now (gracefully)
    try {
        if (!(Get-Process "DNSAgent.Tray" -ErrorAction SilentlyContinue)) {
            Start-Process $TrayPath -WorkingDirectory $CurrentDir
        }
    }
    catch {
        Write-Host "Note: Tray app could not be started automatically. You can start it manually from $TrayPath" -ForegroundColor Yellow
    }
}

Write-Host "`nSUCCESS: DNS Agent is installed and running correctly!" -ForegroundColor Green
Write-Host "Dashboard: http://localhost:5123" -ForegroundColor Cyan
pause
